package models;

import java.io.Serializable;

public enum Sexe implements Serializable  {
	MASCULIN, FEMININ, INCONNU;
}